import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.Semaphore;


public class OperatingSystem {
	
	public static ArrayList<Thread> ProcessTable;
 static int Printsem=1;
 static int Readsem=1;
 static int Writesem=1;
 static int Takeinpsem=1;
//	public static int activeProcess= 0;
	//system calls:
 
 public static  void semReadWait() {
		Readsem=0;
		
	}
	public static void SemReadPost() {
		Readsem=1;
	}
	// 1- Read from File resource 1 
	@SuppressWarnings("unused")
	public static String readFile(String name) {
		String Data="";
		File file = new File(name);
	 try {
		Scanner scan = new Scanner(file);
		while (scan.hasNextLine())
		{
			Data+= scan.nextLine()+"\n";
		}
		scan.close();
	} catch (FileNotFoundException e) {
		System.out.println(e.getMessage());
	}
		return Data;
	}
	public static void semWriteWait() {
		Writesem=0;
		
	}
	public static void SemWritePost() {
		Writesem=1;
	}
	// 2- Write into file resource 2
	@SuppressWarnings("unused")
	public static void writefile(String name, String data) {
		try
		{
			BufferedWriter BW = new BufferedWriter(new FileWriter(name));
			BW.write(data);
			BW.close();
		} 
		catch (IOException e) 
		{
			System.out.println(e.getMessage());
		}

	}
	public static void semPrintWait() {
		Printsem=0;
		
	}
	public static void SemPrintPost() {
		Printsem=1;
	}
	//3- print to console resource 3
	@SuppressWarnings("unused")
	public static void printText(String text) {

		System.out.println(text);
		
	}
	
	public static void semTakeWait() {
		Takeinpsem=0;
		
	}
	public static void SemTakePost() {
		Takeinpsem=1;
	}
	
	//4- take input resource 4 
	
	@SuppressWarnings("unused")
	public static String TakeInput() {
		Scanner in= new Scanner(System.in);
		String data = in.nextLine();
		return data;
		
	}
	
	private static void createProcess(int processID) throws InterruptedException{
		Process p = new Process(processID);
		ProcessTable.add(p);
		Process.setProcessState(p,ProcessState.Ready);
		
		if(ProcessTable.indexOf(p)!=0) {
			

			while(ProcessTable.indexOf(p)!=0&&((Process)ProcessTable.get(ProcessTable.indexOf(p)-1)).status!=ProcessState.Terminated) {
				p.sleep(100);
			}
		}
		p.start();
		
	}
	
	
	public static void main(String[] args) throws InterruptedException {
   		ProcessTable = new ArrayList<Thread>();

		createProcess(1);
		createProcess(2);
		createProcess(3);
		createProcess(4);
		createProcess(5);

	}
}



